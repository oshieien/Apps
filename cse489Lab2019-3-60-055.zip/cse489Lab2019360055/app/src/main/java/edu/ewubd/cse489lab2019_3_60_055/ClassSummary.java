package edu.ewubd.cse489lab2019_3_60_055;
public class ClassSummary {
    String id = "";
    String course = "";
    String type = "";
    long date = 0;
    String lecture = "";
    String topic = "";
    String summary = "";


    public ClassSummary(String id, String course,String type, long date, String lecture,String topic , String summary){
        this.id = id;
        this.course = course;
        this.type = type;

        this.date= date;
        this.lecture=lecture;
        this.topic=topic;
        this.summary=summary;



    }
}
