
package edu.ewubd.cse489lab2019_3_60_055;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import androidx.annotation.NonNull;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class ClassSummaryAdapter extends ArrayAdapter<ClassSummary> {

    private final Context context;
    private final ArrayList<ClassSummary> values;

    public ClassSummaryAdapter(@NonNull Context context, @NonNull ArrayList<ClassSummary> items) {
        super(context, -1, items);
        this.context = context;
        this.values = items;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View rowView = inflater.inflate(R.layout.row_lecture, parent, false);

        TextView topic = rowView.findViewById(R.id.tvtopic);
        TextView date = rowView.findViewById(R.id.tvdate);
        TextView summary = rowView.findViewById(R.id.tvsummary);
        //TextView eventType = rowView.findViewById(R.id.tvEventType);

        ClassSummary e = values.get(position);
        summary.setText(e.summary);
        String dateString =convertTimestampToDate(e.date);
        Log.d("tag", dateString);
        date.setText(dateString);
        topic.setText(e.topic);
        //eventType.setText(e.eventType);
        return rowView;


        }

    private static String convertTimestampToDate(long timestamp) {
        // Create a Date object from the timestamp
        Date date = new Date(timestamp);

        // Create a SimpleDateFormat object with the desired format
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

        // Format the Date object into a String
        return dateFormat.format(date);
    }
}









