package edu.ewubd.cse489lab2019_3_60_055;



import static edu.ewubd.cse489lab2019_3_60_055.R.id.calendarView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.crashlytics.buildtools.reloc.org.apache.http.NameValuePair;
import com.google.firebase.crashlytics.buildtools.reloc.org.apache.http.message.BasicNameValuePair;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ClassSummaryActivity extends AppCompatActivity {

    private EditText etDate, etLecture, etTopic, etSummary;
    private TextView tvName, tvId,etcourse;

    private Button btnCancel, btnSave;
    private RadioButton rb1, rb2, rb3, rb4, rbTheory, rbLab;

    private String uniqueId = "";

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_summary);
        Intent i = getIntent();

        etDate = findViewById(R.id.etDate);
        etLecture = findViewById(R.id.etlecnum);
        etTopic = findViewById(R.id.ettopic);
        etSummary = findViewById(R.id.lecsum);
        tvName = findViewById(R.id.tvName);
        tvId = findViewById(R.id.tvId);
        btnCancel = findViewById(R.id.etcans);
        btnSave = findViewById(R.id.etsave);
        etcourse=findViewById(R.id.etcourse);

        rbTheory = findViewById(R.id.rbtheory);
        rbLab = findViewById(R.id.classrbLab);

        if(i.hasExtra("courseName")){
            String title = i.getStringExtra("courseName");
            etcourse.setText(title);
        }

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSummary();
            }
        });

    }

    private void saveSummary() {
        ClassSummaryDB db = new ClassSummaryDB(this);
        String course = etcourse.getText().toString();

        String date = etDate.getText().toString().trim();
        String lecture = etLecture.getText().toString().trim();
        String topic = etTopic.getText().toString().trim();
        String summary = etSummary.getText().toString().trim();

        String datePattern = "^\\d{2}-\\d{2}-\\d{4}$";
        String errorMsg = "";



        String type = "";
        if (rbTheory.isChecked()) {
            type = "Theory";
        } else if (rbLab.isChecked()) {
            type = "Lab";
        }


        if (!(rbTheory.isChecked() || rbLab.isChecked())) {
            errorMsg += "select any type first\n";
        }
        if (!date.matches(datePattern)) {
            errorMsg += "invalid date\n";
        }
        if (lecture.isEmpty()) {
            errorMsg += "Enter Lecture Number\n";
        }
        if (topic.length() > 15) {
            errorMsg += "topic should be max 15 letters\n";
        }
        if (summary.isEmpty()) {
            errorMsg += "Summary can not be empty\n";
        }

        if (!errorMsg.isEmpty()) {
            showErrorDialog(errorMsg);
            return;

        } else {
            if (uniqueId.isEmpty()) {
                uniqueId = topic + System.currentTimeMillis();
               long timestamp = convertDateToTimestamp(date);
                db.insertLecture(uniqueId, course, type, timestamp, lecture, topic, summary);

                String keys[] = {"action", "sid", "semester", "id", "course", "type", "date", "lecture", "topic", "summary"};
                String values[] = {"backup", "2019-3-60-055", "2024-1",uniqueId, course, type, date, lecture, topic, summary};
                httpRequest(keys, values);

                showSuccessDialog("Data Inserted");

            } else {
               long timestamp = convertDateToTimestamp(date);
                db.updateLecture(uniqueId, course, type, timestamp, lecture, topic, summary);
                showSuccessDialog("Data Updated");
                finish();
            }

        }
    }

    private long convertDateToTimestamp(String date) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
            Date parsedDate = dateFormat.parse(date);
            return parsedDate.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }

    private void showErrorDialog(String errorMessage) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(errorMessage);
        builder.setTitle("Error");
        builder.setCancelable(true);

        builder.setPositiveButton("Back", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    private void showSuccessDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message);
        builder.setTitle("Success");
        builder.setCancelable(true);

        builder.setPositiveButton("Back", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
                finish();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    @SuppressLint("StaticFieldLeak")
    private void httpRequest(final String keys[], final String values[]){
        new AsyncTask<Void,Void,String>(){
            @Override
            protected String doInBackground(Void... voids) {
                List<NameValuePair> params=new ArrayList<NameValuePair>();
                for (int i=0; i<keys.length; i++){
                    params.add(new BasicNameValuePair(keys[i],values[i]));
                }
                String url= "https://www.muthosoft.com/univ/cse489/index.php";
                try {
                    String data= RemoteAccess.getInstance().makeHttpRequest(url,"POST",params);
                    return data;
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
            protected void onPostExecute(String data){
                if(data!=null){
                    Toast.makeText(getApplicationContext(),data,Toast.LENGTH_SHORT).show();
                }
            }
        }.execute();
    }


}