package edu.ewubd.cse489lab2019_3_60_055;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Pattern;

public class Signup extends AppCompatActivity {


    private EditText et_name, et_email, et_phone,et_uid, et_pass, et_pass2;
    private CheckBox cb_remember_uid, cb_remember_pass;
    private  Button bt_go, bt_login, bt_exit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        decideNavigation();

        setContentView(R.layout.activity_signup);


        et_name = findViewById(R.id.etName);
        et_email = findViewById(R.id.etEmail);
        et_phone = findViewById(R.id.etPhNO);
        et_uid = findViewById(R.id.etuserId);
        et_pass = findViewById(R.id.etPassword);
        et_pass2 = findViewById(R.id.etReenterPass);

        cb_remember_uid = findViewById(R.id.checkButton1);
        cb_remember_pass = findViewById(R.id.checkButton2);

        bt_login = findViewById(R.id.etLogin);
        bt_go = findViewById(R.id.etGo);
        bt_exit = findViewById(R.id.etExit);





        bt_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        bt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Signup.this, Login.class);
                startActivity(intent);
                finish();
            }
        });
        bt_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                processSignup();
            }
        });

    }

    private void decideNavigation() {

        SharedPreferences sp = this.getSharedPreferences("user_input",MODE_PRIVATE);
        String name = sp.getString("USER_NAME", "NOT-CREATED");
        if(!name.equals("NOT-CREATED")) {
            Intent intent = new Intent(Signup.this, Login.class);
            startActivity(intent);
            finish();
        }

    }

    private void processSignup() {
        String name = et_name.getText().toString().trim();
        String email = et_email.getText().toString().trim();
        String phone = et_phone.getText().toString().trim();
        String uid = et_uid.getText().toString().trim();
        String pass = et_pass.getText().toString().trim();
        String pass2 = et_pass2.getText().toString().trim();
        String errorMsg = "";

        if(name.length()<4 || name.length()>8)
            errorMsg += "Invalid User Name \n";

        if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches())
            errorMsg += "Invalid Email Address \n";

        if (!((phone.startsWith("+880") && phone.length()==14) ||
                (phone.startsWith("+880") && phone.length()==13) ||
                (phone.startsWith("01") && phone.length()==11))) {
            errorMsg += "Invalid Phone Number \n";
        }

        if(uid.length()<4 || uid.length()>6)
            errorMsg += "Invalid User ID \n";


        if(pass.length()<4 || !pass.equals(pass2))
            errorMsg += "Invalid Password \n";

        if (errorMsg.length()>0) {
            showErrorDialog(errorMsg);
            return;
        }


        SharedPreferences sp = this.getSharedPreferences("user_input",MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();
        e.putString("USER_NAME",name);
        e.putString("USER_EMAIL",email);
        e.putString("USER_PHONE",phone);
        e.putString("USER_UID",uid);
        e.putString("USER_PASS",pass);
        e.putString("USER_PASS2",pass2);

        e.putBoolean("REM_UID",cb_remember_uid.isChecked());
        e.putBoolean("REM_PASS",cb_remember_pass.isChecked());
        e.commit();

        Intent intent = new Intent(Signup.this, MainActivity.class);
        startActivity(intent);
        finish();

    }

    private void showErrorDialog(String errorMsg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(errorMsg);
        builder.setTitle("Error");
        builder.setCancelable(true);
        builder.setPositiveButton("Back", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }
}