package edu.ewubd.cse489lab2019_3_60_055;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;

        import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.crashlytics.buildtools.reloc.org.apache.http.NameValuePair;
import com.google.firebase.crashlytics.buildtools.reloc.org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private Button btnCSE477, btnCSE479,btnCSE489,btnCSE495;
    private Button btnExit;
    private Button btnNew;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCSE477 = findViewById(R.id.rb1);
        btnCSE479 = findViewById(R.id.rb2);
        btnCSE489 = findViewById(R.id.rb3);
        btnCSE495 = findViewById(R.id.rb4);

        btnCSE477.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSummary("CSE477");
            }
        });

        btnCSE479.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSummary("CSE479");
            }
        });

        btnCSE489.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSummary("CSE489");
            }
        });

        btnCSE495.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSummary("CSE495");
            }
        });

        findViewById(R.id.btnExit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    @Override
    protected void onStart() {
        super.onStart();
        String keys[] = {"action", "sid", "semester"};
        String values[] = {"restore", "2019-3-60-055", "2024-1"};
        httpRequest(keys, values);
    }
    @SuppressLint("StaticFieldLeak")
    private void httpRequest(final String keys[], final String values[]){
        new AsyncTask<Void,Void,String>(){
            @Override
            protected String doInBackground(Void... voids) {
                List<NameValuePair> params=new ArrayList<NameValuePair>();
                for (int i=0; i<keys.length; i++){
                    params.add(new BasicNameValuePair(keys[i],values[i]));
                }
                String url= "https://www.muthosoft.com/univ/cse489/index.php";
                try {
                    String data= RemoteAccess.getInstance().makeHttpRequest(url,"POST",params);
                    return data;
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
            protected void onPostExecute(String data){
                if(data!=null){
                    updateLocalDBByServerData(data);
                }
            }
        }.execute();
    }

    private void updateLocalDBByServerData (String data){
        System.out.println("found");
        try{
            JSONObject jo = new JSONObject(data);
            if(jo.has("classes")){
                //classes.clear();
                JSONArray ja = jo.getJSONArray("classes");
                for(int i=0; i<ja.length(); i++){
                    JSONObject summary = ja.getJSONObject(i);
                    String id = summary.getString("id");
                    String course = summary.getString("course");
                    String topic = summary.getString("topic");
                    String type = summary.getString("type");
                    long date = summary.getLong("date");
                    String lecture = summary.getString("lecture");
                    String sum = summary.getString("summary");

//                    ClassSummaryDB db= new ClassSummaryDB(this);
//                    db.insertLecture(id,course,type,date,lecture,topic,sum);
                    // Write code here to insert lecture information in SQL Database
                }
            }
        }catch(Exception e){}
    }
    public void openSummary(String courseName) {
        Intent intent = new Intent(this, lectureList.class);
        intent.putExtra("courseName", courseName);
        startActivity(intent);
//        finish();
    }
}
