package edu.ewubd.mycontacts;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class ContactListAdapter extends ArrayAdapter<Contact> {
    public ContactListAdapter(Context context, ArrayList<Contact> contacts) {
        super(context, 0, contacts);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Contact contact = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.contact_list_item, parent, false);
        }
        TextView nameTextView = convertView.findViewById(R.id.nameTextView);
        TextView emailTextView = convertView.findViewById(R.id.emailTextView);
        TextView homePhoneTextView = convertView.findViewById(R.id.homePhoneTextView);
        TextView officePhoneTextView = convertView.findViewById(R.id.officePhoneTextView);

        nameTextView.setText(contact.getName());
        emailTextView.setText(contact.getEmail());
        homePhoneTextView.setText(contact.getHomePhone());
        officePhoneTextView.setText(contact.getOfficePhone());

        return convertView;
    }
}
