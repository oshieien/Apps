package edu.ewubd.mycontacts;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class ContactListActivity extends AppCompatActivity {
    private Button btnAddContact;
    private DatabaseHelper dbHelper;
    private ContactListAdapter adapter;
    private ArrayList<Contact> contactList = new ArrayList<>();
    private ListView contactListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_contact_list);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        dbHelper = new DatabaseHelper(this);
        contactListView = findViewById(R.id.contactListView);

        adapter = new ContactListAdapter(this, contactList);
        contactListView.setAdapter(adapter);

        contactListView.setOnItemClickListener((parent, view, position, id) -> {
            int contactId = contactList.get(position).getId();
            Intent intent = new Intent(ContactListActivity.this, ContactEditActivity.class);
            intent.putExtra("CONTACT_ID", contactId);
            startActivity(intent);
        });

        loadContacts();

        Button btnAddContact = findViewById(R.id.btnAddContact);
        btnAddContact.setOnClickListener(v -> {
            Intent intent = new Intent(ContactListActivity.this, ContactForm.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadContacts();
    }

    private void loadContacts() {
        ArrayList<Contact> updatedContacts = dbHelper.getAllContacts();
        contactList.clear();
        contactList.addAll(updatedContacts);
        adapter.notifyDataSetChanged();
    }
}