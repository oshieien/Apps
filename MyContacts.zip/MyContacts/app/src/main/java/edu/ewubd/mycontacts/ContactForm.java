package edu.ewubd.mycontacts;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Objects;

public class ContactForm extends AppCompatActivity {
    private EditText etName, etEmail, etHomePhone, etOfficePhone;
    private Button btnCancel, btnSave;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_contact_form);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etHomePhone = findViewById(R.id.etHomePhone);
        etOfficePhone = findViewById(R.id.etOfficePhone);

        btnSave = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);

        dbHelper = new DatabaseHelper(this);

        btnCancel.setOnClickListener(v -> {
            finish();
        });

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String homePhone = etHomePhone.getText().toString().trim();
            String officePhone = etOfficePhone.getText().toString().trim();

            boolean isValid = validateInput(name, email, homePhone, officePhone);

            if (isValid) {
                if (!name.isEmpty() && !email.isEmpty() && !homePhone.isEmpty() && !officePhone.isEmpty()) {
                    SQLiteDatabase db = dbHelper.getWritableDatabase();
                    ContentValues values = new ContentValues();
                    values.put(DatabaseHelper.COLUMN_NAME, name);
                    values.put(DatabaseHelper.COLUMN_EMAIL, email);
                    values.put(DatabaseHelper.COLUMN_HOME_PHONE, homePhone);
                    values.put(DatabaseHelper.COLUMN_OFFICE_PHONE, officePhone);

                    long newRowId = db.insert(DatabaseHelper.TABLE_CONTACTS, null, values);
                    if (newRowId != -1) {
                        Toast.makeText(ContactForm.this, "Contact added successfully", Toast.LENGTH_SHORT).show();
                        // Clear input fields after insertion
                        etName.getText().clear();
                        etEmail.getText().clear();
                        etHomePhone.getText().clear();
                        etOfficePhone.getText().clear();
                        Intent intent = new Intent(ContactForm.this, ContactListActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(ContactForm.this, "Failed to add contact", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ContactForm.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean validateInput(String name, String email, String homePhone, String officePhone) {
        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(email) || TextUtils.isEmpty(homePhone) || TextUtils.isEmpty(officePhone)) {
            displayErrorDialog("Please fill all fields");
            return false;
        } else if (!isValidEmail(email)) {
            displayErrorDialog("Invalid email address");
            return false;
        } else {
            return true;
        }
    }

    private boolean isValidEmail(String email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private void displayErrorDialog(String message) {
        new AlertDialog.Builder(this)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }
}
