package edu.ewubd.mycontacts;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LoginActivity extends AppCompatActivity {
    private EditText etEmail, etPassword;
    private Button btnExit, btnGo, btnSignup;
    private SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);

        btnExit = findViewById(R.id.btnExit);
        btnGo = findViewById(R.id.btnGo);
        btnSignup = findViewById(R.id.btnSignup);

        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        etEmail.setText(sharedPreferences.getString("etEmail", ""));
        etPassword.setText(sharedPreferences.getString("password", ""));

        btnExit.setOnClickListener(v -> finish());

        btnGo.setOnClickListener(v -> {
            String Email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (isDataValid(Email, password)) {
                // Authenticate user and proceed to MainActivity
                Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginActivity.this, ContactListActivity.class);
                startActivity(intent);
                finish();
            } else {
                showErrorDialog(Email, password);
            }
        });
        btnSignup.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
            startActivity(intent);
        });
    }

    private boolean isDataValid(String email, String password) {
        String signupEmail = sharedPreferences.getString("etEmail", "");
        String signupPassword = sharedPreferences.getString("etPassword", "");

        return email.equals(signupEmail) && password.equals(signupPassword);
    }

    private void showErrorDialog(String userId, String password) {
        StringBuilder errMsg = new StringBuilder();
        if (userId.isEmpty() || userId.length() < 5) {
            errMsg.append("- User ID must be at least 5 characters long\n");
        }
        if (password.isEmpty() || password.length() < 6) {
            errMsg.append("- Password must be at least 6 characters long\n");
        }

        if (errMsg.length() > 0) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Error");
            builder.setMessage(errMsg.toString());
            builder.setCancelable(true);
            builder.setPositiveButton("OK", (dialog, id) -> dialog.dismiss()); // Changed to "OK" button
            AlertDialog alert = builder.create();
            alert.show();
        } else {
            // Show error if credentials don't match
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Error");
            builder.setMessage("Invalid User ID or Password");
            builder.setCancelable(true);
            builder.setPositiveButton("OK", (dialog, id) -> dialog.dismiss());
            AlertDialog alert = builder.create();
            alert.show();
        }
    }
}
