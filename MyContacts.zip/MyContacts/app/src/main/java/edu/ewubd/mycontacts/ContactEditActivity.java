package edu.ewubd.mycontacts;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ContactEditActivity extends AppCompatActivity {
    private EditText etName, etEmail, etHomePhone, etOfficePhone;
    private Button btnUpdate, btnDelete;
    private DatabaseHelper dbHelper;
    private int contactId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_contact_edit);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        dbHelper = new DatabaseHelper(this);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etHomePhone = findViewById(R.id.etHomePhone);
        etOfficePhone = findViewById(R.id.etOfficePhone);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);

        contactId = getIntent().getIntExtra("CONTACT_ID", -1);

        loadContactDetails();

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateContact();
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Delete contact from SQLite database
                deleteContact();
            }
        });
    }

    private void loadContactDetails() {
        Contact contact = dbHelper.getContact(contactId);
        if (contact != null) {
            etName.setText(contact.getName());
            etEmail.setText(contact.getEmail());
            etHomePhone.setText(contact.getHomePhone());
            etOfficePhone.setText(contact.getOfficePhone());
        }
    }

    private void updateContact() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String homePhone = etHomePhone.getText().toString().trim();
        String officePhone = etOfficePhone.getText().toString().trim();

        boolean updated = dbHelper.updateContact(contactId, name, email, homePhone, officePhone);
        if (updated) {
            Toast.makeText(this, "Contact updated successfully", Toast.LENGTH_SHORT).show();
            finish(); // Close activity after updating
        } else {
            Toast.makeText(this, "Failed to update contact", Toast.LENGTH_SHORT).show();
        }
    }


    private void deleteContact() {
        boolean deleted = dbHelper.deleteContact(contactId);
        if (deleted) {
            Toast.makeText(this, "Contact deleted successfully", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to delete contact", Toast.LENGTH_SHORT).show();
        }
    }
}
