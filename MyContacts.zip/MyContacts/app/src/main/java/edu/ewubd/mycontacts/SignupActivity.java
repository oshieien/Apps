package edu.ewubd.mycontacts;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SignupActivity extends AppCompatActivity {


    private EditText etName, etEmail, etPhone, etPassword, etRePassword;
    private Button btnExit, btnGo, btnLogin;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_signup);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etPassword = findViewById(R.id.etPassword);
        etRePassword = findViewById(R.id.etRePassword);

        btnExit = findViewById(R.id.btnExit);
        btnGo = findViewById(R.id.btnGo);
        btnLogin = findViewById(R.id.btnLogin);

        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();

        etName.setText(sharedPreferences.getString("name", ""));
        etEmail.setText(sharedPreferences.getString("email", ""));
        etPhone.setText(sharedPreferences.getString("phone", ""));
        etPassword.setText(sharedPreferences.getString("password", ""));
        etRePassword.setText(sharedPreferences.getString("rePassword", ""));

        btnExit.setOnClickListener(v -> finish());

        // Clear input fields
        etName.setText("");
        etEmail.setText("");
        etPhone.setText("");
        etPassword.setText("");
        etRePassword.setText("");

        btnGo.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String phone = etPhone.getText().toString().trim();
            String password = etPassword.getText().toString().trim();
            String rePassword = etRePassword.getText().toString().trim();

            if (isDataValid(name, email, phone, password, rePassword)) {
                editor.remove("etEmail").remove("etPassword").apply();
                if (password.equals(rePassword)) {
                    storeDataInSharedPreferences(name, email, phone, password, rePassword);
                    Toast.makeText(SignupActivity.this, "Signup Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    showErrorDialog("Passwords do not match");
                }
            }

        });

        btnLogin.setOnClickListener(v -> {
            Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
            startActivity(intent);
        });
    }

    private boolean isDataValid(String name, String email, String phone, String password, String rePassword) {
        StringBuilder errMsg = new StringBuilder();
        if (name.isEmpty() || name.length() < 3) {
            errMsg.append("- Name must be at least 3 characters long\n");
        }
        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            errMsg.append("- Invalid email address\n");
        }
        if (phone.isEmpty() || !android.util.Patterns.PHONE.matcher(phone).matches()) {
            errMsg.append("- Invalid phone number\n");
        }
        if (password.isEmpty() || password.length() < 6) {
            errMsg.append("- Password must be at least 6 characters long\n");
        }
        if (rePassword.isEmpty() || rePassword.length() < 6) {
            errMsg.append("- Re-entered password must be at least 6 characters long and matched with password\n");
        }

        if (errMsg.length() > 0) {
            showErrorDialog(errMsg.toString());
            return false;
        }
        return true;
    }


    private void storeDataInSharedPreferences(String name, String email, String phone, String password, String rePassword) {
        editor.putString("etName", name);
        editor.putString("etEmail", email);
        editor.putString("etPhone", phone);
        editor.putString("etPassword", password);
        editor.putString("etRePassword", rePassword);
        editor.apply();
    }


    private void showErrorDialog(String errorMessage) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Error");
        builder.setMessage(errorMessage);
        builder.setCancelable(true);
        builder.setPositiveButton("Back", (dialog, id) -> dialog.cancel());
        AlertDialog alert = builder.create();
        alert.show();
    }
}
