package edu.ewubd.mycontacts;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "contacts.db";
    private static final int DATABASE_VERSION = 1;
    public static final String TABLE_CONTACTS = "contacts";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_HOME_PHONE = "home_phone";
    public static final String COLUMN_OFFICE_PHONE = "office_phone";

    public Contact getContact(int contactId) {
        ArrayList<Contact> contactList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Contact contact = null;
        Cursor cursor = db.query(TABLE_CONTACTS,
                new String[]{COLUMN_ID, COLUMN_NAME, COLUMN_EMAIL, COLUMN_HOME_PHONE, COLUMN_OFFICE_PHONE},
                COLUMN_ID + " = ?",
                new String[]{String.valueOf(contactId)},
                null, null, null);


        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
                String email = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMAIL));
                String homePhone = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_HOME_PHONE));
                String officePhone = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_OFFICE_PHONE));

                contact = new Contact(id, name, email, homePhone, officePhone);
                contactList.add(contact);
            } while (cursor.moveToNext());
            cursor.close();
        }

        db.close();

        return contact;
    }

    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + TABLE_CONTACTS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    COLUMN_NAME + " TEXT," +
                    COLUMN_EMAIL + " TEXT," +
                    COLUMN_HOME_PHONE + " TEXT," +
                    COLUMN_OFFICE_PHONE + " TEXT)";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CONTACTS);
        onCreate(db);
    }

    public long insertContact(String name, String email, String homePhone, String officePhone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_HOME_PHONE, homePhone);
        values.put(COLUMN_OFFICE_PHONE, officePhone);
        long result = db.insert(TABLE_CONTACTS, null, values);
        db.close();
        return result;
    }

    public ArrayList<Contact> getAllContacts() {
        ArrayList<Contact> contactList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_CONTACTS, null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
                String email = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMAIL));
                String homePhone = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_HOME_PHONE));
                String officePhone = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_OFFICE_PHONE));
                Contact contact = new Contact(id, name, email, homePhone, officePhone);
                contactList.add(contact);
            } while (cursor.moveToNext());
            cursor.close();
        }

        db.close();
        return contactList;
    }

    public boolean updateContact(int contactId, String name, String email, String homePhone, String officePhone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_HOME_PHONE, homePhone);
        values.put(COLUMN_OFFICE_PHONE, officePhone);
        int rowsAffected = db.update(TABLE_CONTACTS, values, COLUMN_ID + "=?",
                new String[]{String.valueOf(contactId)});
        db.close();
        return rowsAffected > 0;
    }

    public boolean deleteContact(int contactId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(TABLE_CONTACTS, COLUMN_ID + "=?",
                new String[]{String.valueOf(contactId)});
        db.close();
        return rowsAffected > 0;
    }
}
